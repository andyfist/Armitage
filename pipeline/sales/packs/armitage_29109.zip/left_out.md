# Left out of the Chrome check: Armitage armitage_29109

Heavy or bulky lots, large furniture, whitegoods and vehicles (Andy, 21 Oct and 7 Nov 2026). To put one back, say "add lot <n> to the Chrome pack" in the Auction scans project.

| Lot | Title | Why |
|---|---|---|
| 692 | GOEBEL BEDSIDE LAMP H-56 CM | large furniture |
| 897 | TEDDY BEAR, SCHOOL DESK & RUG | heavy or bulky |
