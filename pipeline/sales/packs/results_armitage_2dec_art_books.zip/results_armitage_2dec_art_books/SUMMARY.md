# Armitage 2 Dec 2026: art and books, Chrome run summary

Lot list rebuilt from the live catalogues (no chunks folder was supplied): 128 lots (9 books/paper, 119 art). All 128 done.

## Worth bidding (resale, max hammer)
1. 1317 Donald Friend '3 Nudes, Bali', ink/gouache/w'col 73x48: resale ~A$3,800 hammer; max $2,480. No bids, est 2,000-2,500. Closes 6:34 PM. Check back for gallery labels (authenticity).
2. 1111 Edith Holmes, blossom in green jug, oil ~42x36: resale ~A$3,200; max $2,065. No bids, est 2,000-3,000. Closes 5:26 PM. Read the exhibition card on the mat.
3. 1077 '5 artworks incl 2 Bea Maddock': two Maddock 'Red Text' sheets XXV & XXVI (1984, Ritchies Mill): resale ~A$1,100 pair; max $600. No bids. Closes 5:14 PM. Thin evidence (1 sale at A$550).
4. 851 'W. Menzies-Gibb gorge scene' = William Menzies Gibb (NZ), Otira Gorge with Cobb & Co coach, w'col: resale ~A$450 in NZ; max $145 (indicative). Bid $15. Closes 3:59 PM.
5. 1756 box of 1960s Footy Fan / Sporting Life mags: max $45 (rises if 20+ Footy Fans). Bid $10.
6. 915 Early Houses of Northern Tasmania, signed ltd ed 615/1000: resale ~A$305; max $45; BID PAST MAX ($130).

## Check at viewing
- 1118: catalogued von Guerard, actually J.S. Prout 'The Cataract, Launceston' composition (1844); caption differs from the original, so original vs reproduction is the question. Could be A$300-500 if original.
- 1100 colonial portrait in Huon pine frame (sitter name on back?); 1182 birdseye Huon pine frame; 1154 19th C English watercolour; 879 Tasmanian deeds (dates); 1714 TASMAP box (old/HEC maps); 686 silver frame hallmark.

## Catalogue errors
- 1118 is Prout, not von Guerard.
- 851 is the NZ painter William Menzies Gibb.
- 1077's 'Bea Maddock' are two Red Text sheets (artist's statement verso).
- 833/835 Pro Hart etchings are UNSIGNED publisher's proofs.
- 1316's signature doesn't read as 'Terence Alexander'.

## Counts
128 done; 6 with a max; 4 escalated; most of the rest are local amateur or decorative work with no resale market (incl. 10 Ryllton Viney studio lots, 2 Alison Cooper-White).
