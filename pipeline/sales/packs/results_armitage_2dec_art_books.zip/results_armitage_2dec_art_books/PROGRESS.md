# Armitage 2 Dec 2026, art and books, Chrome run (started 27 Nov 2026 20:29)

## Setup notes
- No `chunks` folder or zip came with PROMPT.md, and this chat can't reach Andy's PC files. Lot list rebuilt from the four live catalogues (chid 29109, 29110, 29111, 29113) by keyword scan: 127 art, book and paper lots in `candidates.txt`. No cloud_scan notes.
- Running from the Chrome side panel: helpers can't use Chrome, so every lot is done in this one chat, one tab, sequentially.
- Lot page URL: https://armitage.bidsonline.com.au/catalogue_detail.aspx?cdid=<cdid>&chid=<chid>

## Step 0: what works
- eBay Seller Hub research (Terapeak): WORKS, sold tab, 3-year window.
- WorthPoint / LiveAuctioneers: check hung (browser disconnected), re-test when needed.
- AASD/artrecord: NOT logged in (prices paywalled). Invaluable: not logged in, sold prices hidden; lot links usable. appraisily.com artist profiles give Invaluable-sourced prices.

- Terapeak: open https://www.ebay.com.au/sh/research?marketplace=EBAY-AU&keywords=...&dayRange=1095&tabName=SOLD then read rows ([data-item-id] = item no). Its /api/search endpoint returns nothing; use the page.
- Photos: lot images at /images/products/<id>_<n>.jpg; screenshots of raw image URLs fail, so rebuild the lot page body with the <img>s via JS and screenshot.
- Work order in ORDER.txt (128 lots, books first then art best-first).

## Done: ALL 128 lots (chunk: lot (max hammer))
- A01: 739 (0), 874 (0), 905 (0), 915 (45), 1125 (0)
- A02: 879 (0), 896 (0), 1634 (0), 1756 (45)
- B01: 832 (0), 1101 (0), 1118 (0, esc), 1166 (0), 1317 (2480, esc)
- B02: 845 (0), 847 (0), 849 (0), 1102 (0), 1111 (2065, esc)
- B03: 834 (0), 850 (0), 1100 (0), 1112 (0), 1119 (0)
- B04: 833 (0), 835 (0), 1077 (600, esc), 1108 (0), 1153 (0)
- B05: 1113 (0), 1117 (0), 1123 (0), 1162 (0), 1182 (0)
- B06: 1105 (0), 1106 (0), 1107 (0), 1324 (0), 1338 (0)
- B07: 1120 (0), 1311 (0), 1313 (0), 1314 (0), 1316 (0)
- B08: 1159 (0), 1160 (0), 1161 (0), 1310 (0), 1315 (0)
- B09: 1152 (0), 1154 (0), 1158 (0), 1163 (0), 1165 (0)
- B10: 1155 (0), 1326 (0), 1327 (0), 1328 (0), 1329 (0)
- B11: 1319 (0), 1320 (0), 1323 (0), 1339 (0), 1341 (0)
- B12: 837 (0), 1332 (0), 1334 (0), 1342 (0), 1344 (0)
- B13: 1094 (0), 1095 (0), 1097 (0), 1114 (0), 1127 (0)
- B14: 1092 (0), 1141 (0), 1172 (0), 1174 (0), 1288 (0)
- B15: 1098 (0), 1099 (0), 1103 (0), 1104 (0), 1109 (0)
- B16: 1110 (0), 1115 (0), 1116 (0), 1147 (0), 1286 (0)
- B17: 686 (0), 727 (0), 728 (0), 729 (0), 730 (0)
- B18: 731 (0), 732 (0), 737 (0), 792 (0), 827 (0)
- B19: 851 (145), 852 (0), 860 (0), 861 (0), 862 (0)
- B20: 863 (0), 864 (0), 870 (0), 871 (0), 1076 (0)
- B21: 1079 (0), 1265 (0), 1321 (0), 1322 (0), 1333 (0)
- B22: 1266 (0), 2402 (0), 2406 (0), 2408 (0), 2465 (0)
- B23: 1553 (0), 2101 (0), 2511 (0), 2513 (0), 2523 (0)
- B24: 942 (0), 1714 (0), 1745 (0), 1749 (0)

Finished 27 Nov 2026. Current bids re-checked at the end: 1317 none, 1111 none, 1077 none, 851 $15, 915 $130 (past max), 1756 $10, 1118 $40.
