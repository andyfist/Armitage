# Left out of the Chrome check: Armitage armitage_29110_29111_29113

Heavy or bulky lots, large furniture, whitegoods and vehicles (Andy, 21 Oct and 7 Nov 2026). To put one back, say "add lot <n> to the Chrome pack" in the Auction scans project.

| Lot | Title | Why |
|---|---|---|
| 1093 | A HAND-KNOTTED PERSIAN ENJELAS... | heavy or bulky |
| 1096 | A TRIBAL AFGHAN TURKOMAN RUG 1... | heavy or bulky |
| 1128 | A NEW CONTEMPORARY GALAXY DESI... | heavy or bulky |
| 1131 | BALTIC PINE CHEST OF DRAWERS H... | large furniture |
| 1138 | PINE KITCHEN DRESSER H-213 W-1... | large furniture |
| 1145 | LOW OAK STAINED COFFEE TABLE H... | large furniture |
| 1156 | CHINESE CARVED HARDWOOD SECRET... | large furniture |
| 1169 | HANDMADE GRIZZLY BEAR RUG BY L... | heavy or bulky |
| 1190 | A HAND-KNOTTED TRIBAL PERSIAN ... | heavy or bulky |
| 1192 | A WOOLLEN PILE PERSIAN TOYSERK... | heavy or bulky |
| 1194 | A HAND-KNOTTED TRIBAL PERSIAN ... | heavy or bulky |
| 1207 | A TRIBAL AFGHAN MAZAR TURKOMAN... | heavy or bulky |
| 1211 | A TRIBAL PERSIAN BIDJAR BIDGAN... | heavy or bulky |
| 1220 | A HAND-KNOTTED PERSIAN KASHAN ... | heavy or bulky |
| 1222 | FRENCH KINGWOOD INLAID LADIES ... | large furniture |
| 1225 | BAMBOO & LACQUERED 2 DOOR DISP... | large furniture |
| 1226 | OAK & PINE OPEN BOOKSHELF H-12... | large furniture |
| 1229 | A WOOLLEN PILE PERSIAN TOYSERK... | heavy or bulky |
| 1235 | OAK JACOBEAN STYLE SIDEBOARD H... | large furniture |
| 1243 | A NEW CONTEMPORARY TRANSITIONA... | heavy or bulky |
| 1244 | BURR WALNUT INLAID COFFEE TABL... | large furniture |
| 1248 | VICTORIAN CARVED MAHOGANY PIAN... | heavy or bulky |
| 1255 | LARGE MOBILE OAK TOP KITCHEN W... | heavy or bulky |
| 1262 | MODERN VINTAGE OVER-DYED PERSI... | heavy or bulky |
| 1267 | FINE CARVED FRENCH WALNUT DOUB... | large furniture |
| 1270 | A TRIBAL PERSIAN NAHAVAND RUG ... | heavy or bulky |
| 1283 | CAST IRON & BRASS SINGLE BED | large furniture |
| 1284 | CONTEMPORARY FINE VINTAGE OVER... | heavy or bulky |
| 1287 | JARRAH REFECTORY STYLE DINING ... | large furniture |
| 1293 | A NOMADIC PERSIAN KURDISH KILI... | heavy or bulky |
| 1295 | OAK ARTS & CRAFTS WARDROBE H-1... | large furniture |
| 1297 | HIGHLAND CATTLE FLOOR RUG W-18... | heavy or bulky |
| 1299 | MAHOGANY 4 LEGGED SIDEBOARD C1... | large furniture |
| 1300 | PAIR OF BRASS & METAL DESK LAM... | large furniture |
| 1325 | MAHOGANY HALF ROUND DISPLAY CA... | large furniture |
| 1331 | SCANDINAVIAN PINE BIEDERMEIER ... | large furniture |
| 1449 | 1980 DATSUN 1200 MANUAL UTE, U... | motor vehicle |
| 1450 | 2005 HOLDEN COMMODORE BERLINA ... | motor vehicle |
| 1451 | 2009 BT-50 2 WHEEL DRIVE FLAT ... | motor vehicle |
| 1453 | METAL & WOODEN FRAMED 6X4 HOME... | motor vehicle |
| 1454 | 2025 RED SHOPRIDER RAIN RIDER ... | motor vehicle |
| 1492 | ALCOCK & CO CAST IRON BILLIARD... | heavy or bulky |
| 1500 | MAKITA LS1019 260MM SLIDE COMP... | heavy or bulky |
| 1501 | A REPCO 12 VOLT HEAVY DUTY AIR... | heavy or bulky |
| 1503 | MAKITA MITRE SAW STAND WST06 -... | heavy or bulky |
| 1506 | MASPORT P60 MASTER PRESSURE WA... | heavy or bulky |
| 1511 | KARCHER PRESSURE WASHER - AS N... | heavy or bulky |
| 1531 | MALVERN STAR LADIES BIKE WITH ... | heavy or bulky |
| 1649 | 2 PRESSURE WASHER ATTACHMENTS | heavy or bulky |
| 1725 | FISKARS LOG SPLITTER | heavy or bulky |
| 1744 | 3 X 3 METRE GAZEBO COMPLETE WI... | heavy or bulky |
| 1754 | GMC 150 MM BAND SAW - GOING OR... | heavy or bulky |
| 1765 | HITACHI SLIDING MITRE SAW - GO... | heavy or bulky |
| 1788 | RYOBI COMPOUND MITRE SAW - GOI... | heavy or bulky |
| 1828 | HITACHI 255 MM COMPOUND MITRE ... | heavy or bulky |
| 1845 | BLACK POLY TUB WHEELBARROW | heavy or bulky |
| 1849 | WHITE PAINTED ALUMINIUM 3 PIEC... | heavy or bulky |
| 1850 | CONCRETE BIRD BATH H-68 CM | heavy or bulky |
| 1855 | 3 YELLOW METAL BAR STOOLS | large furniture |
| 1859 | CAST IRON BIRD BATH - DAMAGED ... | heavy or bulky |
| 1868 | 4 BURNER BBQ | heavy or bulky |
| 1876 | GREEN METAL TUB WHEELBARROW | heavy or bulky |
| 1882 | SAUCER CHAIR WITH MATCHING SID... | large furniture |
| 1889 | METAL TUB WHEELBARROW | heavy or bulky |
| 1895 | CANNONDALE BIKE FRAME & PAIR O... | heavy or bulky |
| 1908 | 7 PIECE TIMBER OUTDOOR SETTING | heavy or bulky |
| 1914 | VINTAGE CANVAS CANOE WITH PADD... | heavy or bulky |
| 1933 | 6 X 20 LITRE OF OUTBOARD OIL (... | heavy or bulky |
| 1958 | JOHNSON 6 HP OUTBOARD ON STAND... | heavy or bulky |
| 1974 | HARDWOOD WORK BENCH WITH 3 VIC... | heavy or bulky |
| 1978 | GALVANISED TUB WHEELBARROW | heavy or bulky |
| 1979 | 3 PIECE GARDEN FOUNTAIN - DAMA... | heavy or bulky |
| 1982 | ELECTRIC PRESSURE WASHER - MOT... | heavy or bulky |
| 1983 | CAST IRON & ALUMINIUM BLACK PA... | heavy or bulky |
| 1986 | METAL 2 TIER FLAT BED TROLLEY | large furniture |
| 1994 | VINTAGE ELECTRIC CEMENT MIXER ... | heavy or bulky |
| 1995 | HONDA PETROL ROTARY HOE | motor vehicle |
| 1996 | POLY TUB CONCRETERS WHEELBARRO... | heavy or bulky |
| 2023 | STIHL RE 129 ELECTRIC PRESSURE... | heavy or bulky |
| 2041 | 2 SPINIFEX CAMP RECLINER CHAIR... | large furniture |
| 2046 | TIMBER WORK BENCH WITH VICE H-... | heavy or bulky |
| 2048 | 9 PIECE WOVEN PLASTIC OUTDOOR ... | heavy or bulky |
| 2063 | TOUREX MOUNTAIN BIKE & A PEAK ... | heavy or bulky |
| 2064 | HUFFY & SHOGUN MOUNTAIN BIKES ... | heavy or bulky |
| 2066 | ENCHANT CHILDS MOUNTAIN BIKE | heavy or bulky |
| 2067 | GIRLS SOUTHERN STAR PUSH BIKE ... | heavy or bulky |
| 2070 | MONGOOSE MOUNTAIN BIKE | heavy or bulky |
| 2071 | HOLLAND LADIES BIKE | heavy or bulky |
| 2072 | MONTERAY BIKE WITH HELM... | heavy or bulky |
| 2073 | RED ASCEND MOUNTAIN BIKE | heavy or bulky |
| 2074 | LIV CHILDS MOUNTAIN BIKE | heavy or bulky |
| 2075 | MALVERN STAR MOUNTAIN BIKE WIT... | heavy or bulky |
| 2076 | VICTA LAWNMOWER WITH CATCHER | motor vehicle |
| 2077 | MTD LAWNMOWER | motor vehicle |
| 2078 | VICTA LAWNMOWER | motor vehicle |
| 2079 | HONDA HRN 216 SELF PROPELLED M... | heavy or bulky |
| 2081 | SCORPION 2.2 HP COMPRESSOR WIT... | heavy or bulky |
| 2083 | GOODWELL WELDER WITH FACE SHIE... | heavy or bulky |
| 2085 | ZIEGLAR & BROWN TRIPLE GRILL B... | heavy or bulky |
| 2086 | GIANT GIRLS MOUNTAIN BIKE | heavy or bulky |
| 2090 | KARCHER PRESSURE WASHER - MOTO... | heavy or bulky |
| 2092 | PERFORMANCE AIR COMPRESSOR - G... | heavy or bulky |
| 2104 | GOODWELL AIR COMPRESSOR WITH H... | heavy or bulky |
| 2107 | BOAT TRAILER PARTS INCLUDING W... | motor vehicle |
| 2116 | OUTDOOR SEAT CUSHIONS | heavy or bulky |
| 2123 | SUNBEAM KETTLE BBQ ON STAND | heavy or bulky |
| 2348 | HISENSE STAINLESS STEEL FRONT ... | whitegoods |
| 2350 | HAIER FRIDGE/FREEZER H-142 W-5... | whitegoods |
| 2351 | LG DIRECT DRIVE 7 KG FRONT LOA... | whitegoods |
| 2354 | ELECTROLUX 5.5 KG CLOTHES DRYE... | whitegoods |
| 2356 | ASKO W6222 FRONT LOADING WASHI... | whitegoods |
| 2358 | FISHER & PAYKEL CLOTHES DRYER ... | whitegoods |
| 2360 | WESTINGHOUSE FRIDGE/FREEZER H-... | whitegoods |
| 2361 | PANASONIC 49" LCD TV & REMOTE... | heavy or bulky |
| 2375 | DIMPLEX PORTABLE AIR CONDITION... | whitegoods |
| 2380 | ELECTRIC FOLDING TREADMILL - G... | heavy or bulky |
| 2391 | SPINMAXX EXERCISE BIKE | heavy or bulky |
| 2393 | FISHER & PAYKEL 5.5 KG TOP LOA... | whitegoods |
| 2394 | TREK EVOLUTION 4 MOBILITY SCOO... | motor vehicle |
| 2400 | 6 DRAWER, 3 DOOR GLAZED TOP DI... | large furniture |
| 2403 | PINE & METAL DOUBLE BED WITH I... | large furniture |
| 2410 | LARGE PINE BOOKCASE H-194 W-12... | large furniture |
| 2411 | LAZ-Y-BOY MAROON LEATHER RECLI... | large furniture |
| 2414 | LA-Z-BOY RIALTO GREY FABRIC LIF... | large furniture |
| 2417 | BUNDABERG GREY MICROSUEDE RECL... | large furniture |
| 2418 | TCL 43 INCH SMART TV WITH REMO... | heavy or bulky |
| 2420 | LARGE TEAK GLASS TOP DINING TA... | large furniture |
| 2423 | PINE 2 DRAWER SIDE TABLE H-80 ... | large furniture |
| 2424 | HISENSE 40" SMART TV & REMOTE... | heavy or bulky |
| 2432 | OAK BEDSIDE CHEST H-65 CM | large furniture |
| 2434 | PAIR OF BEDSIDE CHESTS H-65 CM | large furniture |
| 2436 | TIMBER & CANE COFFEE TABLE WIT... | large furniture |
| 2438 | 2 WHITE BEDSIDE UNITS | large furniture |
| 2442 | TAN RECLINER CHAIR | large furniture |
| 2443 | TAN LEATHER UPHOLSTERED 3 SEAT... | large furniture |
| 2447 | 3 PIECE DARK GREEN LEATHER LOU... | large furniture |
| 2448 | BLUE FABRIC RECLINER CHAIR | large furniture |
| 2451 | FABRIC 3 PIECE LOUNGE SUITE | large furniture |
| 2452 | PINE 2 DRAWER BEDSIDE CHEST H-... | large furniture |
| 2454 | PAIR PINE BEDSIDE CHESTS H-64 ... | large furniture |
| 2463 | FABRIC 3 SEATER COUCH WITH CUS... | large furniture |
| 2466 | CLICK-CLACK SOFA | large furniture |
| 2470 | TEAK SIDEBOARD H-84 W-150 D-43... | large furniture |
| 2471 | 9 DRAWER LEATHER INLAID DESK H... | large furniture |
| 2473 | 5 PIECE INLAID OAK DINING SUIT... | large furniture |
| 2476 | PAIR OF BLACK GAS LIFT BAR STO... | large furniture |
| 2477 | TEAK 2 DRAWER SIDE TABLE H-75 ... | large furniture |
| 2482 | OAK SIDEBOARD H-91 W-165 D-50 ... | large furniture |
| 2491 | 2 DRAWER FILING CABINET H-77 W... | large furniture |
| 2493 | OAK 2 DRAWER COFFEE TABLE H-43... | large furniture |
| 2494 | PAIR OF OAK 3 DRAWER BEDSIDE T... | large furniture |
| 2495 | LIVE EDGE RED GUM COFFEE TABLE... | large furniture |
| 2497 | GREY FABRIC CHAISE LOUNGE W-12... | large furniture |
| 2501 | OAKLAND NATURAL BEAUTY CLOUD, ... | large furniture |
| 2506 | BODYWORX EXERCISE BIKE | heavy or bulky |
| 2507 | PAIR OF FABRIC RECLINER ARMCHA... | large furniture |
| 2508 | ELECTRIC ADJUSTABLE SINGLE BED | large furniture |
| 2509 | PINE BOOKCASE/BLANKET CHEST H-... | large furniture |
| 2512 | PINE QUEEN SIZE BED | large furniture |
| 2517 | MODERN METAL QUEEN SIZE BED EN... | large furniture |
| 2518 | PINE BOOKCASE & BLANKET BOX H-... | large furniture |
| 2522 | BISSEL CARPET & HARD FLOOR WAS... | heavy or bulky |
