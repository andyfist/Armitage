# Armitage armitage_29109 progress

27 Nov 2026, 18:10 Hobart

## Step 0: which sites work in Andy's Chrome

| Site | Status |
|---|---|
| eBay Seller Hub research (Terapeak) | WORKS. Signed in as andrewfistau, sold results with prices, 3-year range |
| eBay public sold search | Expected to work (same signed-in eBay) |
| WorthPoint | Search results show, but not signed in (LOG IN showing), so sold prices hidden. Skip |
| LiveAuctioneers | Past results list shows, but prices are "See Winning Bid" behind login. Skip for prices |
| Invaluable | Past lots list shows, "View sold prices" needs login. Skip for prices |
| the-saleroom | Not signed in, past results need login. Skip |

Use instead: Terapeak, eBay sold, Google, Google Lens, public auction results pages (Leonard Joel, Lawsons, Davidson, Theodore Bruce, Gibson's, Shapiro, Leski, Noble, Australian Book Auctions, AWA, AbeBooks, Biblio, Australian Art Sales Digest).

## Lots

0 of 89 chunks done. Lot data loaded from the zip Andy attached (18:05). Running in the cloud workspace; results zip will be sent in this chat because the PC folder can't be written to.

## Log

- 18:57 chunks passing: 11 / 89  lots passing: 55
- 19:02 chunks passing: 11 / 89  lots passing: 62
- 19:07 chunks passing: 13 / 89  lots passing: 67
- 19:12 chunks passing: 14 / 89  lots passing: 71 (2 helpers, eBay error pages)
- 19:17 chunks passing: 14 / 89  lots passing: 73
- 19:22 chunks passing: 15 / 89  lots passing: 76
- 19:27 chunks passing: 15 / 89  lots passing: 79
- 19:32 chunks passing: 16 / 89  lots passing: 83
- 19:41 chunks passing: 17 / 89  lots passing: 92
- 19:46 chunks passing: 19 / 89  lots passing: 97
- 19:56 chunks passing: 19 / 89  lots passing: 105
- 20:01 chunks passing: 22 / 89  lots passing: 112
- 20:13 chunks passing: 25 / 89  lots passing: 127
- 20:19 chunks passing: 27 / 89  lots passing: 140
- 20:29 chunks passing: 29 / 89  lots passing: 147
- 20:34 chunks passing: 29 / 89  lots passing: 154
- 20:44 chunks passing: 30 / 89  lots passing: 161
- 20:49 chunks passing: 34 / 89  lots passing: 170
- 20:50 Lesson: Terapeak rows carry data-item-id even >90 days, so older sales can be linked. Plan a relink pass at the end for lots whose max rests on SOLD-UNLINKED rows.
- 20:56 chunks passing: 35 / 89  lots passing: 180
- 21:01 chunks passing: 37 / 89  lots passing: 184
- 21:01 eBay bot check #1 (seen by another helper on tab 2056140588). eBay paused 10 min. Next one drops to 2 helpers.
- 21:06 chunks passing: 37 / 89  lots passing: 184
- 21:10 chunks passing: 37 / 89  lots passing: 184
- 21:15 chunks passing: 37 / 89  lots passing: 184
- 21:19 chunks passing: 37 / 89  lots passing: 187
- 21:24 chunks passing: 39 / 89  lots passing: 195
- 21:31 chunks passing: 40 / 89  lots passing: 200
- 21:36 chunks passing: 41 / 89  lots passing: 207
- 21:41 chunks passing: 42 / 89  lots passing: 211
- 21:49 chunks passing: 43 / 89  lots passing: 218
- 21:53 chunks passing: 45 / 89  lots passing: 227
- 22:05 chunks passing: 46 / 89  lots passing: 235
- 22:10 chunks passing: 47 / 89  lots passing: 244
- 22:20 chunks passing: 49 / 89  lots passing: 254
- 22:25 chunks passing: 51 / 89  lots passing: 261
- 22:32 chunks passing: 52 / 89  lots passing: 266
- 22:36 chunks passing: 54 / 89  lots passing: 279
- 22:37 eBay bot check #2 (~22:26). Dropped to 2 helpers per rule; a third drops to 1.
- 22:41 chunks passing: 55 / 89  lots passing: 284
- 22:46 chunks passing: 56 / 89  lots passing: 288
- 22:51 chunks passing: 57 / 89  lots passing: 292
- 22:52 eBay bot check #3 reported at 22:48 (second-hand, by D038). Per rule dropped to 1 helper. Note: all bot-check sightings so far were reported by a different helper than the tab's owner.
- 22:57 chunks passing: 57 / 89  lots passing: 292 (1 helper)
- 23:01 chunks passing: 57 / 89  lots passing: 294 (1 helper)
- 23:06 chunks passing: 58 / 89  lots passing: 296 (1 helper)
- 23:11 chunks passing: 58 / 89  lots passing: 298 (1 helper)
- 23:16 chunks passing: 58 / 89  lots passing: 300 (1 helper)
- 23:21 chunks passing: 59 / 89  lots passing: 301 (1 helper)
- 23:26 chunks passing: 59 / 89  lots passing: 303 (1 helper)
- 23:31 chunks passing: 60 / 89  lots passing: 306 (1 helper)
- 23:36 chunks passing: 60 / 89  lots passing: 310 (1 helper)
- 23:41 chunks passing: 60 / 89  lots passing: 310 (1 helper)
- 23:46 chunks passing: 61 / 89  lots passing: 311 (1 helper)
- 01:02 All 441 lots done. Relink pass: 915 (max A$105, bid past), 657 (max A$85, bid past). Others in the relink list are under A$100 or auction-house markets.

## Final (28 Nov 2026)
- 441 of 441 lots done, 89 of 89 chunks pass the check (photos seen, identification, every SOLD has a date and individual listing link).
- 84 lots have a max above A$0. 64 lots have no linked SOLD (one-offs, wine, or nothing comparable sold); each says what was searched.
- Hand-backs: 17 lots re-checked by Opus (E001-E004 files kept for reference; results merged into the D chunks).
- eBay: 3 reported "Pardon our interruption" sightings (21:00, ~22:26, 22:48), all second-hand from another helper's tab; dropped to 1 helper as per rules. Public eBay search often returned "Something went wrong"; Terapeak used throughout.
- From D042 on (after a Chrome tab block and the move to the side panel), lots were priced directly by the main chat (model_used "opus (main chat, side panel)").
- Relink: Terapeak rows older than 90 days carry the eBay item id; lots 915 and 657 were relinked (both bid past max). Other early lots with SOLD-UNLINKED rows are under A$100 or rest on auction-house markets.
- SUMMARY_lots_with_max.csv lists every lot sorted by max hammer.
