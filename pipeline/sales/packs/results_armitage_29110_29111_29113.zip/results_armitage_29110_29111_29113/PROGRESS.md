# PROGRESS: Armitage 29110/29111/29113 Chrome price check

Started 27 Nov 2026 22:30 Hobart. Run from a cloud session linked to Andy's PC, using Claude in Chrome.

## Step 0, site check (27 Nov 2026)
- eBay Seller Hub research (Terapeak): WORKS, signed in (andrewfistau). Use https://www.ebay.com.au/sh/research?marketplace=EBAY-AU&keywords=...&dayRange=1095&tabName=SOLD (also marketplace=EBAY-US / EBAY-GB, dayRange up to 1095).
- WorthPoint: NOT signed in, prices hidden. Skip.
- LiveAuctioneers: not signed in, winning bids hidden ("See Winning Bid"). Skip for prices.
- Invaluable, the-saleroom: untested at start; helpers note what they find.
- Use eBay public sold search, Google, Google Lens, auction house public results pages.

## eBay bot checks
1. ~22:55 27 Nov, Terapeak 'Pardon our interruption' seen in one tab; eBay paused ~10 min. 
2. ~23:41 27 Nov, Terapeak 'Pardon our interruption' in a helper tab; eBay paused to 23:52. Dropped to 2 helpers.
3. ~00:55 28 Nov, 'Pardon our interruption' briefly in D007 helper's tab (reported by D006 helper). Dropped to 1 helper from D008 on.
4. ~01:00 28 Nov, D007 helper hit one on a listing page (lot 1719); backed off 10 min. Already at 1 helper, pacing raised to 15 s.
5. 28 Nov morning (D062-D066): eBay public sold search returned 'Something went wrong' error pages several times (no 'Pardon our interruption'). Helpers paused eBay public search 10 min and used Terapeak; pacing raised to 20 s.
6. 28 Nov 12:30: Andy chose to go back to 2 helpers (overriding the 1-helper rule), from D122.
7. ~15:55 28 Nov, 'Pardon our interruption' in the D165 helper's tab (lot 2519), the other tab too. eBay paused 10 min, then fine. Staying at 2 helpers (Andy's call); if another hits, drop to 1.
8. 28 Nov ~16:10: Part D finished. Opus recheck started: 82 lots in E001-E017 (escalated lots, extras, and vintage hi-fi Andy asked for). Sonnet originals kept; Opus result replaces Sonnet in the D files.
9. 28 Nov ~19:45: Opus recheck finished (E001-E017, 82 lots), merged into the D files (each rechecked lot has rechecked_in and sonnet_max_hammer). C001 escalate flags cleared. All 181 C/D chunks pass the check. Zipped.

## Terapeak shared filter (23:40 27 Nov)
Terapeak filters live in Andy's account and are shared across helper tabs; the condition filter got stuck on 'Brand New' and won't clear. From C012 on, helpers never touch Terapeak filters, note which filter was on, and use eBay public sold search for used prices. C001-C011 helpers mostly reported checking/clearing it, but a final audit of Terapeak-only lots is worthwhile.

## Scope
Parts A and B skipped (art and books prompt). Lots 869 and 1756 skipped. Part C (15 chunks, Opus), then Part D (166 chunks, Sonnet).

## Status
Updated 28 Nov 17:23 Hobart. Chunks done and checked: 181 of 181. In progress or partial: none.
Done: C001, C002, C003, C004, C005, C006, C007, C008, C009, C010, C011, C012, C013, C014, C015, D001, D002, D003, D004, D005, D006, D007, D008, D009, D010, D011, D012, D013, D014, D015, D016, D017, D018, D019, D020, D021, D022, D023, D024, D025, D026, D027, D028, D029, D030, D031, D032, D033, D034, D035, D036, D037, D038, D039, D040, D041, D042, D043, D044, D045, D046, D047, D048, D049, D050, D051, D052, D053, D054, D055, D056, D057, D058, D059, D060, D061, D062, D063, D064, D065, D066, D067, D068, D069, D070, D071, D072, D073, D074, D075, D076, D077, D078, D079, D080, D081, D082, D083, D084, D085, D086, D087, D088, D089, D090, D091, D092, D093, D094, D095, D096, D097, D098, D099, D100, D101, D102, D103, D104, D105, D106, D107, D108, D109, D110, D111, D112, D113, D114, D115, D116, D117, D118, D119, D120, D121, D122, D123, D124, D125, D126, D127, D128, D129, D130, D131, D132, D133, D134, D135, D136, D137, D138, D139, D140, D141, D142, D143, D144, D145, D146, D147, D148, D149, D150, D151, D152, D153, D154, D155, D156, D157, D158, D159, D160, D161, D162, D163, D164, D165, D166
Lot-level check failures to redo: none
